<?php
include("conexion.php");
$conn = $conexion;
$id=$_GET['id'];
$pg = "SELECT * FROM tb_users WHERE id_users ='$id'";
$query = pg_query($conn,$pg);
$row=pg_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<header>
    <br><br><br><br><br>
</header>
<body>
    <div class="container mt-5">
        <h1>Modificar datos</h1>
        <form action="update.php" method="POST">
            <input type="hidden" name="id_users" value ="<?php echo $row['id_users']?>">
            <label for="nombre">Nombre</label><br>
            <input type="text" class="form-control mb-3" name="nombre_users" placeholder="Nombres" value="<?php echo $row['nombre_users']?>">
            <label for="documento">Documento</label><br>
            <input type="text" class="form-control mb-3" name="documento_users" placeholder="Documentos" value="<?php echo $row['documento_users']?>">
            <label for="contrasena">Contraseña</label><br>
            <input type="text" class="form-control mb-3" name="contrasena_users" placeholder="Contraseñas" value="<?php echo $row['contrasena_users']?>">
            <label for="id_eps_users">Seleccione su genero</label><br>
                <select class ="form-control mb-3" name="genero_users" value="<?php echo $row['genero_users']?>">
                <option value="" >Seleccionar...</option>
                <option value="F">Femenino</option>
                <option value="M">Masculino</option>
                </select>
                <label for="fecha_nacimiento">Fecha de nacimiento</label><br>
            <input type="date" class="form-control mb-3" name="fecha_users" value="<?php echo $row['fecha_users']?>">
            <label for="telefono">Telefono</label><br>
            <input type="text" class="form-control mb-3" name="telefono_users" placeholder="Telefonos" value="<?php echo $row['telefono_users']?>">
            <label for="create_users">Fecha de creacion</label><br>
            <input type="date" class="form-control mb-3" name="create_users" value="<?php echo $row['create_users']?>">
            <label for="id_eps_users">Seleccione su EPS</label><br>
                <select class ="form-control mb-3" name="id_eps_users" value="<?php echo $row['id_eps_users']?>">
                <option value="" >Seleccionar...</option>
                <option value="123">Nueva EPS</option>
                <option value="321">Sanitas</option>
                </select>
                <label for="id_roles_users">Seleccione su rol</label><br>
                <select class ="form-control mb-3" name="id_roles_users" value="<?php echo $row['id_roles_users']?>">
                <option value="" >Seleccionar...</option>
                <option value="321">Doctor</option>
                <option value="123">Paciente</option>
                </select>
                <input type="submit" class="btn btn-primary btn-block" value="Actualizar">
                <a class="btn btn-primary btn-block" href="usuario.php" role="button">Volver</a>
                <input type="reset" class="btn btn-primary">
        </form>
    </div>
</body>
<br>
    <section class="footer">
        <div class="container text-center">
            <p>Hechor por Nicolás</p>
        </div>
    </section>
</html>