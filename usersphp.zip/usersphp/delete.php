<?php
include("conexion.php");
$conn = $conexion;

$id_users=$_GET['id'];
$pg="DELETE FROM tb_users WHERE id_users='$id_users'";
$query = pg_query($conn,$pg);
if($query){
    Header("Location: usuario.php");
}
?>