<?php
$conexion = pg_connect("host=localhost dbname=db_users user=postgres password=075283");
?>