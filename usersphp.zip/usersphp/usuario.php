<?php
    include("conexion.php");
    $conn = $conexion;
    $pg = "SELECT * FROM tb_users";
    $query = pg_query($conn,$pg);
    $row = pg_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAGINA USUARIOS</title>
    <link rel="stylesheet" href="css/styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<header>
<br><br><br><br><br>
</header>
<body>
    <br>
    <h1 class="titulo">CONTROL DE USUARIOS</h1>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-3">
            <h1>Ingreso de datos</h1>
            <form action="insertar.php" method="POST">
                <label for="id_users">Id</label><br>
                <input type="text" class="form-control mb-3" name="id_users" placeholder="Digite su ID">
                <label for="nombre_users">Nombre</label><br>
                <input type="text" class="form-control mb-3" name="nombre_users" placeholder="Digite su nombre">
                <label for="documento_users">Documento</label><br>
                <input type="text" class="form-control mb-3" name="documento_users" placeholder="Digite su Documento">
                <label for="contrasena_users">Contraseña</label><br>
                <input type="text" class="form-control mb-3" name="contrasena_users" placeholder="Digite su contraseña">
                <label for="id_genero">Seleccione su genero</label><br>
                <select class ="form-control mb-3" name="genero_users">
                <option value="" >Seleccionar...</option>
                <option value="F">Femenino</option>
                <option value="M">Masculino</option>
                </select>
                <label for="fecha_users">Fecha de nacimiento</label><br>
                <input type="date" class="form-control mb-3" name="fecha_users">
                <label for="telefono_users">Telefono</label><br>
                <input type="text" class="form-control mb-3" name="telefono_users" placeholder="Digite su numero de telefono">
                <label for="create_users">Fecha de creacion</label><br>
                <input type="date" class="form-control mb-3" name="create_users">
                <label for="id_eps_users">Seleccione su EPS</label><br>
                <select class ="form-control mb-3" name="id_eps_users">
                <option value="">Seleccionar...</option>
                <option value="123">Nueva EPS</option>
                <option value="321">Sanitas</option>
                </select>
                <label for="id_roles_users">Seleccione su rol</label><br>
                <select class ="form-control mb-3" name="id_roles_users">
                <option value="" >Seleccionar...</option>
                <option value="321">Doctor</option>
                <option value="123">Paciente</option>
                </select>

                <input type="submit" class="btn btn-primary">
                <input type="reset" class="btn btn-primary">
            </form>
            </div>
            <div class="col-md-8">
                <h3 class="titulo">Lista de datos</h3>
                <table class="table">
                    <thead class="table-success table-striped">
                        <tr>
                            <th>Id</th>
                            <th>Nombres</th>
                            <th>Documentos</th>
                            <th>Contraseñas</th>
                            <th>Generos</th>
                            <th>Fechas nacimiento</th>
                            <th>Telefonos</th>
                            <th>Fechas creacion</th>
                            <th>EPS</th>
                            <th>ROL</th>
                            <th>Editar</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while($row=pg_fetch_array($query)){
                            ?>
                        <tr>
                            <th><?php echo $row['id_users']?></th>
                            <th><?php echo $row['nombre_users']?></th>
                            <th><?php echo $row['documento_users']?></th>
                            <th><?php echo $row['contrasena_users']?></th>
                            <th><?php echo $row['genero_users']?></th>
                            <th><?php echo $row['fecha_users']?></th>
                            <th><?php echo $row['telefono_users']?></th>
                            <th><?php echo $row['create_users']?></th>
                            <th><?php echo $row['id_eps_users']?></th>
                            <th><?php echo $row['id_roles_users']?></th>
                            <th><a href="actualizar.php?id=<?php echo $row['id_users']?>" class="btn btn-info">Editar</a></th>
                            <th><a href="delete.php?id=<?php echo $row['id_users']?>" class="btn btn-danger">Eliminar</a></th>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </body>
    <br>
    <section class="footer">
        <div class="container text-center">
            <p>Hechor por Nicolás</p>
        </div>
    </section>

</html>