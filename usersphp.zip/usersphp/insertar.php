<?php
include("conexion.php");
$conn = $conexion;

$id_users=$_POST['id_users'];
$nombre_users=$_POST['nombre_users'];
$documento_users=$_POST['documento_users'];
$contrasena_users=$_POST['contrasena_users'];
$genero_users=$_POST['genero_users'];
$fecha_users=$_POST['fecha_users'];
$telefono_users=$_POST['telefono_users'];
$create_users=$_POST['create_users'];
$id_eps_users=$_POST['id_eps_users'];
$id_roles_users=$_POST['id_roles_users'];

$pg ="INSERT INTO tb_users VALUES ('$id_users','$nombre_users','$documento_users','$contrasena_users','$genero_users','$fecha_users','$telefono_users','$create_users','$id_eps_users','$id_roles_users')";
$query = pg_query($conn,$pg);
if($query){
    Header("Location: usuario.php");
}
else{
    
}

?>