/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.edu.sena.user.view;

import com.edu.sena.user.business.TbLoginBeanLocal;
import com.edu.sena.user.model.TbLogin;
import java.io.IOException;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import org.primefaces.component.inputtext.InputText;
import org.primefaces.component.password.Password;

/**
 * fecha:1/08/2022
 * @author Aprendiz
 * objetivo: administrar la vista del login
 */
@Named(value = "loginView")
@SessionScoped
public class LoginView implements Serializable {
    
    private InputText txtNombre;
    private Password password;
    private TbLogin usuarioLogueado;
    
    @EJB
    private TbLoginBeanLocal tbLoginBean;
    
    /**
     * Creates a new instance of LoginView
     */
    public LoginView() {
    }

    public InputText getTxtNombre() {
        return txtNombre;
    }

    public void setTxtNombre(InputText txtNombre) {
        this.txtNombre = txtNombre;
    }

    public Password getPassword() {
        return password;
    }

    public void setPassword(Password password) {
        this.password = password;
    }

    public TbLogin getUsuarioLogueado() {
        return usuarioLogueado;
    }

    public void setUsuarioLogueado(TbLogin usuarioLogueado) {
        this.usuarioLogueado = usuarioLogueado;
    }
    
    public void clean(){
        txtNombre.setValue("");
        password.setValue("");
    }
    
    //inicia session del usuario
    public void login(){
        try {
            String page = "Usuarios.xhtml";
            usuarioLogueado = new TbLogin();
            usuarioLogueado.setUsuario(txtNombre.getValue().toString());
            usuarioLogueado.setPassword(password.getValue().toString());
            //ejecuto el login
                tbLoginBean.login(usuarioLogueado.getUsuario(), usuarioLogueado.getPassword());
            
            
            // guarda en la session usuario
            FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("usuarioLogueado", usuarioLogueado);
            FacesContext.getCurrentInstance().getExternalContext().redirect(page);
                        
            
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage
                (FacesMessage.SEVERITY_ERROR,"Error",e.getMessage()));
        }
    }
    
    //cierra sesion del usuario
    public void signOut(){
        
        try {
            FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
            ExternalContext context = FacesContext.getCurrentInstance().getExternalContext();
            String path = ((ServletContext) context.getContext()).getContextPath();
            context.redirect(path + "?faces-redirect=true");
        } catch (IOException e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage
                (FacesMessage.SEVERITY_ERROR,"Error",e.getMessage()));
        }
    }
}