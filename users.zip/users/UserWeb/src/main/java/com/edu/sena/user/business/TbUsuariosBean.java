/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.business;

import com.edu.sena.user.model.TbUsuarios;
import com.edu.sena.user.persistencia.ITbUsuariosDAO;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author
 */
@Stateless
public class TbUsuariosBean implements TbUsuariosBeanLocal {

    @EJB
    private ITbUsuariosDAO tbusuariosDAO;

    public void validate(TbUsuarios tbusuarios) throws Exception {
        if (tbusuarios == null) {
            throw new Exception("El usuaro es nulo");
        }
        if (tbusuarios.getId()==null) {
            throw new Exception("La id de el usuario es obligatorio");
        }
        if (tbusuarios.getNombre()==null) {
            throw new Exception("El nombre de el usuario es obligatorio");
        }
        if (tbusuarios.getDocumento()==null) {
            throw new Exception("El documento de el usuario es obligatorio");
        }
        if (tbusuarios.getPassword()==null) {
            throw new Exception("La contraseña de el usuario es obligatorio");
        }
        if (tbusuarios.getGenero()==null) {
            throw new Exception("El genero de el usuario es obligatorio");
        }
        if (tbusuarios.getFecha()==null) {
            throw new Exception("La fecha de el usuario es obligatorio");
        }
        if (tbusuarios.getTelefono()==null) {
            throw new Exception("El telefono de el usuario es obligatorio");
        }
        if (tbusuarios.getCreate()==null) {
            throw new Exception("El create de el usuario es obligatorio");
        }
        if (tbusuarios.getIdEps()==null) {
            throw new Exception("El id de la eps de el usuario es obligatorio");
        }
        if (tbusuarios.getIdRoles()==null) {
            throw new Exception("El id de el rol de el usuario es obligatorio");
        }
    }

    @Override
    public void insert (TbUsuarios tbusuarios) throws Exception {
        validate(tbusuarios);
         tbusuariosDAO.insert(tbusuarios);

    }

    @Override
    public void update(TbUsuarios tbusuarios) throws Exception {
        validate(tbusuarios);
        TbUsuarios oldTbUsuarios = tbusuariosDAO.findById(tbusuarios.getId());
        if (oldTbUsuarios == null) {
            throw new Exception("No existe un usuario con ese id");
        }
        oldTbUsuarios.setId(tbusuarios.getId());
        tbusuariosDAO.update(oldTbUsuarios);

    }

    @Override
    public void delete(TbUsuarios tbusuarios) throws Exception {
        if (tbusuarios == null) {
            throw new Exception("El usuario es nulo");
        }

        if (tbusuarios.getId() == 0) {
            throw new Exception("El id es obligatorio");
        }

        TbUsuarios oldTbUsuarios = tbusuariosDAO.findById(tbusuarios.getId());

        if (tbusuarios == null) {
            throw new Exception("No existe un usuario con ese id");
        }
        tbusuariosDAO.delete(oldTbUsuarios);
    }

    @Override
    public TbUsuarios findById(Integer id) throws Exception {
        if (id == 0) {
            throw new Exception("El id del usuario es obligatorio");
        }
        return tbusuariosDAO.findById(id);
    }

    @Override
    public List<TbUsuarios> findAll() throws Exception {
        return tbusuariosDAO.findAll();
    }
}
