/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.business;

import com.edu.sena.user.model.TbLogin;
import com.edu.sena.user.persistencia.ITbLoginDAO;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author
 */
@Stateless
public class TbLoginBean implements TbLoginBeanLocal {

    @EJB
    private ITbLoginDAO tbloginDAO;

    public void validate(TbLogin tblogin) throws Exception {
        if (tblogin == null) {
            throw new Exception("El rol es nulo");
        }
        if (tblogin.getUsuario()==null) {
            throw new Exception("El usuario es nulo");
        }
        if (tblogin.getPassword()==null) {
            throw new Exception("La contraseña es nula");
        }
    }
    @Override
    public TbLogin findById(String usuario) throws Exception {
        if (usuario.isEmpty()) {
            throw new Exception("El usuario es obligatorio");
        }
        return tbloginDAO.findById(usuario);
    }

    @Override
    public List<TbLogin> findAll() throws Exception {
        return tbloginDAO.findAll();
    }

    @Override
    public TbLogin login(String usuario, String password) throws Exception {
        if (usuario.isEmpty()) {
            throw new Exception("El usuario es obligatorio");
        }
        //consulto si existe un usuario con el nombre ingresado en el login
        TbLogin oldTbLogin = tbloginDAO.findById(usuario);
        if (oldTbLogin == null) {
            throw new Exception("Usuario incorrecto!");
        }

        if (!oldTbLogin.getPassword().equals(password)) {
            throw new Exception("Usuario incorrecto!");
        }

        return oldTbLogin;
    }
}
