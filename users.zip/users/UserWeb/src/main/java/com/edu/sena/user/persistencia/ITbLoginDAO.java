/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.edu.sena.user.persistencia;

import com.edu.sena.user.model.TbLogin;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author 
 */
@Local
public interface ITbLoginDAO{
    public TbLogin findById(String usuario) throws Exception;
    public List<TbLogin> findAll() throws Exception;
}
