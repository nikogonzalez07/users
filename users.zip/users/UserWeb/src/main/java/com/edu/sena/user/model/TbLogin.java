/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "tb_login")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbLogin.findAll", query = "SELECT t FROM TbLogin t"),
    @NamedQuery(name = "TbLogin.findByUsuario", query = "SELECT t FROM TbLogin t WHERE t.usuario = :usuario"),
    @NamedQuery(name = "TbLogin.findByPassword", query = "SELECT t FROM TbLogin t WHERE t.password = :password")})
public class TbLogin implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "usuario",nullable = false, length = 50)
    private String usuario;
    @Column(name = "password",length = 50)
    private String password;

    public TbLogin() {
    }

    public TbLogin(String usuario) {
        this.usuario = usuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (usuario != null ? usuario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbLogin)) {
            return false;
        }
        TbLogin other = (TbLogin) object;
        if ((this.usuario == null && other.usuario != null) || (this.usuario != null && !this.usuario.equals(other.usuario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.edu.sena.user.model.TbLogin[ usuario=" + usuario + " ]";
    }
    
}
