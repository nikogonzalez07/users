/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.persistencia;

import com.edu.sena.user.model.TbEps;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author
 */
@Stateless
public class TbEpsDAO implements ITbEpsDAO{
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void insert(TbEps tbeps) throws Exception {
try {
            entityManager.persist(tbeps);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public void update(TbEps tbeps) throws Exception {
try {
            entityManager.merge(tbeps);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public void delete(TbEps tbeps) throws Exception {
try {
            entityManager.remove(tbeps);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public TbEps findById(Integer id) throws Exception {
try {
            return entityManager.find(TbEps.class, id);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public List<TbEps> findAll() throws Exception {
try {
            Query query =  entityManager.createNamedQuery("TbEps.findAll");
            return query.getResultList();
        } catch (RuntimeException e) {
            throw e;
        }
    }
}
