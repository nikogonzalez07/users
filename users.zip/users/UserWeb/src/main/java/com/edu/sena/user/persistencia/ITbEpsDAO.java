/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.edu.sena.user.persistencia;

import com.edu.sena.user.model.TbEps;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author 
 */
@Local
public interface ITbEpsDAO{
    public void insert(TbEps tbeps) throws Exception;
    public void update(TbEps tbeps) throws Exception;
    public void delete(TbEps tbeps) throws Exception;
    public TbEps findById(Integer id) throws Exception;
    public List<TbEps> findAll() throws Exception;
}
