/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.business;

import com.edu.sena.user.model.TbRoles;
import com.edu.sena.user.persistencia.ITbRolesDAO;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author
 */
@Stateless
public class TbRolesBean implements TbRolesBeanLocal {

    @EJB
    private ITbRolesDAO tbrolesDAO;

    public void validate(TbRoles tbroles) throws Exception {
        if (tbroles == null) {
            throw new Exception("El rol es nulo");
        }
        if (tbroles.getId()==null) {
            throw new Exception("La id de el rol es nulo");
        }
    }

    @Override
    public void insert(TbRoles tbroles) throws Exception {
        validate(tbroles);
        tbrolesDAO.insert(tbroles);

    }

    @Override
    public void update(TbRoles tbroles) throws Exception {
        validate(tbroles);
        TbRoles oldTbRoles = tbrolesDAO.findById(tbroles.getId());
        if (oldTbRoles == null) {
            throw new Exception("No existe un rol con ese id");
        }
        oldTbRoles.setId(tbroles.getId());
        tbrolesDAO.update(oldTbRoles);

    }

    @Override
    public void delete(TbRoles tbroles) throws Exception {
        if (tbroles == null) {
            throw new Exception("El rol es nulo");
        }

        if (tbroles.getId() == 0) {
            throw new Exception("El id es obligatorio");
        }

        TbRoles oldTbRoles = tbrolesDAO.findById(tbroles.getId());

        if (tbroles == null) {
            throw new Exception("No existe un rol con ese id");
        }
        tbrolesDAO.delete(oldTbRoles);
    }

    @Override
    public TbRoles findById(Integer id) throws Exception {
        if (id == 0) {
            throw new Exception("El id de la eps es obligatorio");
        }
        return tbrolesDAO.findById(id);
    }

    @Override
    public List<TbRoles> findAll() throws Exception {
        return tbrolesDAO.findAll();
    }

    

}
