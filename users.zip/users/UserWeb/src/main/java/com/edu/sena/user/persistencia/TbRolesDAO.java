/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.persistencia;

import com.edu.sena.user.model.TbRoles;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author 
 */
@Stateless
public class TbRolesDAO implements ITbRolesDAO{
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void insert(TbRoles tbroles) throws Exception {
try {
            entityManager.persist(tbroles);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public void update(TbRoles tbroles) throws Exception {
try {
            entityManager.merge(tbroles);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public void delete(TbRoles tbroles) throws Exception {
try {
            entityManager.remove(tbroles);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public TbRoles findById(Integer id) throws Exception {
try {
            return entityManager.find(TbRoles.class, id);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public List<TbRoles> findAll() throws Exception {
try {
            Query query =  entityManager.createNamedQuery("TbRoles.findAll");
            return query.getResultList();
        } catch (RuntimeException e) {
            throw e;
        }
    }
}
