/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.edu.sena.user.persistencia;

import com.edu.sena.user.model.TbRoles;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author 
 */
@Local
public interface ITbRolesDAO{
    public void insert(TbRoles tbroles) throws Exception;
    public void update(TbRoles tbroles) throws Exception;
    public void delete(TbRoles tbroles) throws Exception;
    public TbRoles findById(Integer id) throws Exception;
    public List<TbRoles> findAll() throws Exception;
}
