/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.persistencia;

import com.edu.sena.user.model.TbUsuarios;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Glasses
 */
@Stateless
public class TbUsuariosDAO implements ITbUsuariosDAO{
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void insert(TbUsuarios tbusuarios) throws Exception {
    try {
            entityManager.persist(tbusuarios);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public void update(TbUsuarios tbusuarios) throws Exception {
try {
            entityManager.merge(tbusuarios);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public void delete(TbUsuarios tbusuarios) throws Exception {
try {
            entityManager.remove(tbusuarios);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public TbUsuarios findById(Integer id) throws Exception {
    try {
            return entityManager.find(TbUsuarios.class, id);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public List<TbUsuarios> findAll() throws Exception {
    try {
            Query query =  entityManager.createNamedQuery("TbUsuarios.findAll");
            return query.getResultList();
        } catch (RuntimeException e) {
            throw e;
        }
    }
}
