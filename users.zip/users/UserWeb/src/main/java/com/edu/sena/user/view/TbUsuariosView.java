/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.edu.sena.user.view;

import com.edu.sena.user.business.TbEpsBeanLocal;
import com.edu.sena.user.business.TbRolesBeanLocal;
import com.edu.sena.user.business.TbUsuariosBeanLocal;
import com.edu.sena.user.model.TbEps;
import com.edu.sena.user.model.TbRoles;
import com.edu.sena.user.model.TbUsuarios;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.model.SelectItem;
import org.primefaces.component.commandbutton.CommandButton;
import org.primefaces.component.inputtext.InputText;
import org.primefaces.component.selectonemenu.SelectOneMenu;
import org.primefaces.event.SelectEvent;

/**
 *
 * @author Usuario
 */
public class TbUsuariosView {
    private InputText txtId;
    private InputText txtNombre;
    private InputText txtDocumento;
    private InputText txtPassword;
    private InputText txtGenero;
    private Date Fecha;
    private InputText txtTelefono;
    private Date Create;
    
    private List<TbUsuarios> listUsuarios = null;
    
    private List<SelectItem> itemsRole;
    private SelectOneMenu selectRole;
    private List<SelectItem> itemsEps;
    private SelectOneMenu selectEps;
    
    private CommandButton btnCrear;
    private CommandButton btnModificar;
    private CommandButton btnEliminar;
    
    @EJB
    private TbUsuariosBeanLocal tbUsuariosBean;
    @EJB
    private TbRolesBeanLocal tbRolesBean;
    @EJB
    private TbEpsBeanLocal tbEpsBean;
    
    /**
     * Creates a new instance of TbUsuariosView
     */
    public TbUsuariosView() {
    }

    public InputText getTxtGenero() {
        return txtGenero;
    }

    public void setTxtGenero(InputText txtGenero) {
        this.txtGenero = txtGenero;
    }


    public SelectOneMenu getSelectRole() {
        return selectRole;
    }

    public void setSelectRole(SelectOneMenu selectRole) {
        this.selectRole = selectRole;
    }

    public SelectOneMenu getSelectEps() {
        return selectEps;
    }

    public void setSelectEps(SelectOneMenu selectEps) {
        this.selectEps = selectEps;
    }

    public InputText getTxtId() {
        return txtId;
    }

    public void setTxtId(InputText txtId) {
        this.txtId = txtId;
    }

    public InputText getTxtNombre() {
        return txtNombre;
    }

    public void setTxtNombre(InputText txtNombre) {
        this.txtNombre = txtNombre;
    }

    public InputText getTxtDocumento() {
        return txtDocumento;
    }

    public void setTxtDocumento(InputText txtDocumento) {
        this.txtDocumento = txtDocumento;
    }

    public InputText getTxtPassword() {
        return txtPassword;
    }

    public void setTxtPassword(InputText txtPassword) {
        this.txtPassword = txtPassword;
    }

    public Date getFecha() {
        return Fecha;
    }

    public void setFecha(Date Fecha) {
        this.Fecha = Fecha;
    }

    public InputText getTxtTelefono() {
        return txtTelefono;
    }

    public void setTxtTelefono(InputText txtTelefono) {
        this.txtTelefono = txtTelefono;
    }

    public Date getCreate() {
        return Create;
    }

    public void setCreate(Date Create) {
        this.Create = Create;
    }

    public List<TbUsuarios> getListTbUsuarios() {
        if(listUsuarios == null){
        try {
                listUsuarios = tbUsuariosBean.findAll();
            }
            catch (Exception e) {
                FacesContext.getCurrentInstance().addMessage
                (null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
            }
        }
        return listUsuarios;
    }

    public void setListUsuarios(List<TbUsuarios> listUsuarios) {
        this.listUsuarios = listUsuarios;
    }

   public List<SelectItem> getItemsRole() {
        try {
            List<TbRoles> listRole = tbRolesBean.findAll();
            itemsRole = new ArrayList<>();
            for (TbRoles t: listRole) {
                itemsRole.add(new SelectItem(t.getId(), t.getNombre()));
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage
                (null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
        }  
        return itemsRole;
    }

    public void setItemsRole(List<SelectItem> itemsRole) {
        this.itemsRole = itemsRole;
    }

    public List<SelectItem> getItemsEps() {
        try {
            List<TbEps> listEps = tbEpsBean.findAll();
            itemsEps = new ArrayList<>();
            for (TbEps t: listEps) {
                itemsEps.add(new SelectItem(t.getId(), t.getNombre()));
            }
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage
                (null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
        }  
        return itemsEps;
    }

    public void setItemsEps(List<SelectItem> itemsEps) {
        this.itemsEps = itemsEps;
    }

    public CommandButton getBtnCrear() {
        return btnCrear;
    }

    public void setBtnCrear(CommandButton btnCrear) {
        this.btnCrear = btnCrear;
    }

    public CommandButton getBtnModificar() {
        return btnModificar;
    }

    public void setBtnModificar(CommandButton btnModificar) {
        this.btnModificar = btnModificar;
    }

    public CommandButton getBtnEliminar() {
        return btnEliminar;
    }

    public void setBtnEliminar(CommandButton btnEliminar) {
        this.btnEliminar = btnEliminar;
    }
    public void clear(){
        
        txtId.setValue("");
        txtNombre.setValue("");
        txtDocumento.setValue("");
        txtPassword.setValue("");
        txtTelefono.setValue("");
        txtGenero.setValue("");
        
        Fecha = null;
        Create = null;
        
        listUsuarios = null;
        
        selectEps.setValue(0);
        selectRole.setValue(0);
        
        btnCrear.setDisabled(false);
        btnModificar.setDisabled(true);
        btnEliminar.setDisabled(true);
    }
    public void insert (){
        try {
            TbUsuarios tbUsuarios = new TbUsuarios();
            
            tbUsuarios.setId(Integer.parseInt(txtId.getValue().toString()));
            tbUsuarios.setNombre(txtNombre.getValue().toString());
            tbUsuarios.setDocumento(txtDocumento.getValue().toString());
            tbUsuarios.setPassword(txtPassword.getValue().toString());
            tbUsuarios.setTelefono(txtTelefono.getValue().toString());
            tbUsuarios.setGenero(txtGenero.getValue().toString());
            tbUsuarios.setFecha(Fecha);
            tbUsuarios.setCreate(Create);
            
            TbEps tbeps = tbEpsBean.findById(Integer.parseInt(selectEps.getValue().toString()));
            tbUsuarios.setIdEps(tbeps);
            
            TbRoles tbroles = tbRolesBean.findById(Integer.parseInt(selectRole.getValue().toString()));
            tbUsuarios.setIdRoles(tbroles);

            tbUsuariosBean.insert(tbUsuarios);
            FacesContext.getCurrentInstance().addMessage
            (null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Mensaje", "Usuario creado exitosamente"));
            clear();
        } 
        catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage
            (null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
        }
    }
    public void update (){
        try {
            TbUsuarios tbUsuarios = new TbUsuarios();
            
            tbUsuarios.setId(Integer.parseInt(txtId.getValue().toString()));
            tbUsuarios.setNombre(txtNombre.getValue().toString());
            tbUsuarios.setDocumento(txtDocumento.getValue().toString());
            tbUsuarios.setPassword(txtPassword.getValue().toString());
            tbUsuarios.setTelefono(txtTelefono.getValue().toString());
            tbUsuarios.setGenero(txtGenero.getValue().toString());
            tbUsuarios.setFecha(Fecha);
            tbUsuarios.setCreate(Create);
            
            TbEps tbeps = tbEpsBean.findById(Integer.parseInt(selectEps.getValue().toString()));
            tbUsuarios.setIdEps(tbeps);
            
            TbRoles tbroles = tbRolesBean.findById(Integer.parseInt(selectRole.getValue().toString()));
            tbUsuarios.setIdRoles(tbroles);

            tbUsuariosBean.update(tbUsuarios);
            FacesContext.getCurrentInstance().addMessage
            (null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Mensaje", "Usuario modificado exitosamente"));
            clear();
        } 
        catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage
            (null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
        }
    }
    public void delete (){
        try {
            TbUsuarios tbUsuarios = new TbUsuarios();
            
            tbUsuarios.setId(Integer.parseInt(txtId.getValue().toString()));

            tbUsuariosBean.delete(tbUsuarios);
            FacesContext.getCurrentInstance().addMessage
            (null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Mensaje", "Usuario eliminado exitosamente"));
            clear();
        } 
        catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage
            (null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", e.getMessage()));
        }
    }
    public void onRowSelect(SelectEvent event){
        TbUsuarios tbUsuarios = (TbUsuarios) event.getObject();
        
        txtId.setValue(tbUsuarios.getId());
        txtNombre.setValue(tbUsuarios.getNombre());
        txtDocumento.setValue(tbUsuarios.getDocumento());
        txtPassword.setValue(tbUsuarios.getPassword());
        txtTelefono.setValue(tbUsuarios.getTelefono());
        txtGenero.setValue(tbUsuarios.getGenero());
        
        
        Fecha = tbUsuarios.getFecha();
        Create = tbUsuarios.getCreate();
        
        
        selectRole.setValue(tbUsuarios.getIdRoles());
        selectEps.setValue(tbUsuarios.getIdEps());
        
        btnCrear.setDisabled(true);
        btnModificar.setDisabled(false);
        btnEliminar.setDisabled(false);
    }
}