/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.business;

import com.edu.sena.user.model.TbEps;
import com.edu.sena.user.persistencia.ITbEpsDAO;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 *
 * @author
 */
@Stateless
public class TbEpsBean implements TbEpsBeanLocal {

    @EJB
    private ITbEpsDAO tbepsDAO;

    public void validate(TbEps tbeps) throws Exception {
        if (tbeps == null) {
            throw new Exception("La eps es nula");
        }
        if (tbeps.getId()==null) {
            throw new Exception("La id de la eps es nula");
        }
    }

    @Override
    public void insert(TbEps tbeps) throws Exception {
        validate(tbeps);
        tbepsDAO.insert(tbeps);

    }

    @Override
    public void update(TbEps tbeps) throws Exception {
        validate(tbeps);
        TbEps oldTbEps = tbepsDAO.findById(tbeps.getId());
        if (oldTbEps == null) {
            throw new Exception("No existe una eps con ese id");
        }
        oldTbEps.setId(tbeps.getId());
        tbepsDAO.update(oldTbEps);

    }

    @Override
    public void delete(TbEps tbeps) throws Exception {
        if (tbeps == null) {
            throw new Exception("La eps es nula");
        }

        if (tbeps.getId() == 0) {
            throw new Exception("El id es obligatorio");
        }

        TbEps oldTbEps = tbepsDAO.findById(tbeps.getId());

        if (tbeps == null) {
            throw new Exception("No existe una eps con ese id");
        }
        tbepsDAO.delete(oldTbEps);
    }

    @Override
    public TbEps findById(Integer id) throws Exception {
        if (id == 0) {
            throw new Exception("El id de la eps es obligatorio");
        }
        return tbepsDAO.findById(id);
    }

    @Override
    public List<TbEps> findAll() throws Exception {
        return tbepsDAO.findAll();
    }

    

}
