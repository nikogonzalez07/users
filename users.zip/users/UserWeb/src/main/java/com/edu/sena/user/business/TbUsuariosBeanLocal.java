/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.edu.sena.user.business;

import com.edu.sena.user.model.TbUsuarios;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author
 */
@Local
public interface TbUsuariosBeanLocal{
    public void insert(TbUsuarios tbusuarios) throws Exception;
    public void update(TbUsuarios tbusuarios) throws Exception;
    public void delete(TbUsuarios tbusuarios) throws Exception;
    public TbUsuarios findById(Integer id) throws Exception;
    public List<TbUsuarios> findAll() throws Exception;
}
