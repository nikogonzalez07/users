/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.persistencia;

import com.edu.sena.user.model.TbLogin;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author
 */
@Stateless
public class TbLoginDAO implements ITbLoginDAO{
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public TbLogin findById(String usuario) throws Exception {
        try {
            return entityManager.find(TbLogin.class, usuario);
        } catch (RuntimeException e) {
            throw e;
        }
    }

    @Override
    public List<TbLogin> findAll() throws Exception {
         try {
            Query query =  entityManager.createNamedQuery("TbLogin.findAll");
            return query.getResultList();
        } catch (RuntimeException e) {
            throw e;
        }
    }
}   
