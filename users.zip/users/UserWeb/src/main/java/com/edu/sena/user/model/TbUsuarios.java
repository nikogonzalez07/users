/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.sena.user.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Usuario
 */
@Entity
@Table(name = "tb_usuarios")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbUsuarios.findAll", query = "SELECT t FROM TbUsuarios t"),
    @NamedQuery(name = "TbUsuarios.findById", query = "SELECT t FROM TbUsuarios t WHERE t.id = :id"),
    @NamedQuery(name = "TbUsuarios.findByNombre", query = "SELECT t FROM TbUsuarios t WHERE t.nombre = :nombre"),
    @NamedQuery(name = "TbUsuarios.findByDocumento", query = "SELECT t FROM TbUsuarios t WHERE t.documento = :documento"),
    @NamedQuery(name = "TbUsuarios.findByPassword", query = "SELECT t FROM TbUsuarios t WHERE t.password = :password"),
    @NamedQuery(name = "TbUsuarios.findByGenero", query = "SELECT t FROM TbUsuarios t WHERE t.genero = :genero"),
    @NamedQuery(name = "TbUsuarios.findByFecha", query = "SELECT t FROM TbUsuarios t WHERE t.fecha = :fecha"),
    @NamedQuery(name = "TbUsuarios.findByTelefono", query = "SELECT t FROM TbUsuarios t WHERE t.telefono = :telefono"),
    @NamedQuery(name = "TbUsuarios.findByCreate", query = "SELECT t FROM TbUsuarios t WHERE t.create = :create")})
public class TbUsuarios implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id", nullable = false)
    private Integer id;
    @Column(name = "nombre", length = 50)
    private String nombre;
    @Column(name = "documento", length = 50)
    private String documento;
    @Column(name = "password", length = 50)
    private String password;
    @Basic(optional = false)
    @Column(name = "genero", nullable = false, length = 50)
    private String genero;
    @Column(name = "fecha")
    @Temporal(TemporalType.DATE)
    private Date fecha;
    @Column(name = "telefono", length = 50)
    private String telefono;
    @Column(name = "create")
    @Temporal(TemporalType.DATE)
    private Date create;
    @JoinColumn(name = "idEps", referencedColumnName = "id")
    @ManyToOne
    private TbEps idEps;
    @JoinColumn(name = "idRoles", referencedColumnName = "id")
    @ManyToOne
    private TbRoles idRoles;

    public TbUsuarios() {
    }

    public TbUsuarios(Integer id) {
        this.id = id;
    }

    public TbUsuarios(Integer id, String genero) {
        this.id = id;
        this.genero = genero;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Date getCreate() {
        return create;
    }

    public void setCreate(Date create) {
        this.create = create;
    }

    public TbEps getIdEps() {
        return idEps;
    }

    public void setIdEps(TbEps idEps) {
        this.idEps = idEps;
    }

    public TbRoles getIdRoles() {
        return idRoles;
    }

    public void setIdRoles(TbRoles idRoles) {
        this.idRoles = idRoles;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbUsuarios)) {
            return false;
        }
        TbUsuarios other = (TbUsuarios) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.edu.sena.user.model.TbUsuarios[ id=" + id + " ]";
    }
    
}
