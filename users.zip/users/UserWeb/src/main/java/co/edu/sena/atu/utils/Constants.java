/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.sena.atu.utils;

/**
 *
 * @author Aprendiz
 */
public final class Constants {
    public static final String[] LIST_PAGES ={
        "login", "usuarios",
               
    };
}
